import React from 'react';

const CssSection = ({ darkMode }: { darkMode: boolean }) => {
  const sections = [
    {
      title: "Basics of CSS",
      topics: ["Selectors", "Colors", "Typography", "Box Model", "Display Properties"],
      description: "Master the fundamental concepts of CSS styling"
    },
    {
      title: "Layout & Positioning",
      topics: ["Flexbox", "Grid", "Position", "Float", "Media Queries"],
      description: "Learn how to create responsive and dynamic layouts"
    },
    {
      title: "Advanced Styling",
      topics: ["Animations", "Transitions", "Transforms", "Gradients", "Shadows"],
      description: "Explore advanced CSS techniques for modern web design"
    }
  ];

  return (
    <div className="space-y-12">
      <header className="text-center mb-12">
        <h1 className={`text-6xl font-bold mb-4 ${darkMode ? 'text-pink-400' : 'text-pink-600'}`}>
          CSS Zero to Hero
        </h1>
        <p className={`text-xl ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
          Master the art of styling with our comprehensive CSS guide
        </p>
      </header>

      <div className="grid md:grid-cols-3 gap-8">
        {sections.map((section, index) => (
          <div
            key={index}
            className={`p-6 rounded-lg border-2 ${
              darkMode
                ? 'bg-gray-800 border-pink-500 shadow-[0_0_15px_rgba(236,72,153,0.3)]'
                : 'bg-white border-pink-300 shadow-lg'
            } hover:transform hover:scale-105 transition-all duration-300`}
          >
            <h2 className={`text-2xl font-bold mb-4 ${darkMode ? 'text-pink-400' : 'text-pink-600'}`}>
              {section.title}
            </h2>
            <p className={`mb-4 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              {section.description}
            </p>
            <ul className="space-y-2">
              {section.topics.map((topic, topicIndex) => (
                <li
                  key={topicIndex}
                  className={`flex items-center ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}
                >
                  <span className="w-2 h-2 bg-pink-500 rounded-full mr-2"></span>
                  {topic}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CssSection;