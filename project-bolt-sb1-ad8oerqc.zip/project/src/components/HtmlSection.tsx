import React from 'react';

const HtmlSection = ({ darkMode }: { darkMode: boolean }) => {
  const sections = [
    {
      title: "HTML Fundamentals",
      topics: ["Document Structure", "Tags & Elements", "Attributes", "Forms", "Semantic HTML"],
      description: "Learn the building blocks of web development"
    },
    {
      title: "Multimedia & Links",
      topics: ["Images", "Audio", "Video", "Hyperlinks", "iframes"],
      description: "Master embedding media and creating connections"
    },
    {
      title: "Advanced HTML5",
      topics: ["Canvas", "SVG", "Web Storage", "Geolocation", "Web Workers"],
      description: "Explore modern HTML5 features and APIs"
    }
  ];

  return (
    <div className="space-y-12">
      <header className="text-center mb-12">
        <h1 className={`text-6xl font-bold mb-4 ${darkMode ? 'text-blue-400' : 'text-blue-600'}`}>
          HTML Zero to Hero
        </h1>
        <p className={`text-xl ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
          Build the foundation of web development with our comprehensive HTML guide
        </p>
      </header>

      <div className="grid md:grid-cols-3 gap-8">
        {sections.map((section, index) => (
          <div
            key={index}
            className={`p-6 rounded-lg border-2 ${
              darkMode
                ? 'bg-gray-800 border-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.3)]'
                : 'bg-white border-blue-300 shadow-lg'
            } hover:transform hover:scale-105 transition-all duration-300`}
          >
            <h2 className={`text-2xl font-bold mb-4 ${darkMode ? 'text-blue-400' : 'text-blue-600'}`}>
              {section.title}
            </h2>
            <p className={`mb-4 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              {section.description}
            </p>
            <ul className="space-y-2">
              {section.topics.map((topic, topicIndex) => (
                <li
                  key={topicIndex}
                  className={`flex items-center ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}
                >
                  <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                  {topic}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HtmlSection;