import React from 'react';
import { Sun, Moon, Code2, FileCode2 } from 'lucide-react';

interface NavbarProps {
  darkMode: boolean;
  setDarkMode: (value: boolean) => void;
  activeSection: string;
  setActiveSection: (value: string) => void;
}

const Navbar = ({ darkMode, setDarkMode, activeSection, setActiveSection }: NavbarProps) => {
  return (
    <nav className={`${darkMode ? 'bg-gray-800' : 'bg-white'} shadow-lg`}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-8">
            <h1 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
              <span className="text-blue-500">Code</span>
              <span className="text-pink-500">Master</span>
            </h1>
            
            <div className="flex space-x-4">
              <button
                onClick={() => setActiveSection('html')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors ${
                  activeSection === 'html'
                    ? 'bg-blue-500 text-white'
                    : darkMode
                    ? 'text-gray-300 hover:bg-gray-700'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <FileCode2 size={20} />
                <span>HTML</span>
              </button>
              
              <button
                onClick={() => setActiveSection('css')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors ${
                  activeSection === 'css'
                    ? 'bg-pink-500 text-white'
                    : darkMode
                    ? 'text-gray-300 hover:bg-gray-700'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Code2 size={20} />
                <span>CSS</span>
              </button>
            </div>
          </div>
          
          <button
            onClick={() => setDarkMode(!darkMode)}
            className={`p-2 rounded-full ${
              darkMode ? 'bg-gray-700 text-yellow-400' : 'bg-gray-100 text-gray-700'
            }`}
          >
            {darkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;