import React from 'react';

const LoadingScreen = () => {
  return (
    <div className="fixed inset-0 bg-black flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-5xl font-bold mb-4 animate-pulse">
          <span className="text-blue-500">Miami</span>
          <span className="text-pink-500">Tech</span>
          <span className="text-purple-500">Academy</span>
        </h1>
        <div className="w-64 h-2 bg-gray-800 rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-blue-500 via-pink-500 to-purple-500 animate-loading"></div>
        </div>
      </div>
    </div>
  );
}

export default LoadingScreen