import React, { useState, useEffect } from 'react';
import { Sun, Moon, Code2, FileCode2 } from 'lucide-react';
import LoadingScreen from './components/LoadingScreen';
import Navbar from './components/Navbar';
import HtmlSection from './components/HtmlSection';
import CssSection from './components/CssSection';

function App() {
  const [loading, setLoading] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [activeSection, setActiveSection] = useState('css');

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 8000);
    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-900'}`}>
      <Navbar 
        darkMode={darkMode} 
        setDarkMode={setDarkMode}
        activeSection={activeSection}
        setActiveSection={setActiveSection}
      />
      
      <main className="container mx-auto px-4 py-8">
        {activeSection === 'html' ? <HtmlSection darkMode={darkMode} /> : <CssSection darkMode={darkMode} />}
      </main>
    </div>
  );
}

export default App;