import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const HtmlSection = ({ darkMode }: { darkMode: boolean }) => {
  const [expandedSection, setExpandedSection] = useState<number | null>(null);

  const sections = [
    {
      title: "HTML Fundamentals",
      topics: [
        {
          name: "Document Structure",
          example: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document Title</title>
</head>
<body>
    <header>
        <h1>Main Heading</h1>
    </header>
    <main>
        <article>Content here</article>
    </main>
    <footer>
        <p>&copy; 2025</p>
    </footer>
</body>
</html>`,
          explanation: "The HTML document structure provides the foundation for web pages, including metadata, content hierarchy, and semantic organization."
        },
        {
          name: "Forms",
          example: `<form action="/submit" method="POST">
    <div class="form-group">
        <label for="username">Username:</label>
        <input type="text" 
               id="username" 
               name="username" 
               required>
    </div>
    
    <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" 
               id="password" 
               name="password" 
               minlength="8">
    </div>
    
    <div class="form-group">
        <label for="country">Country:</label>
        <select id="country" name="country">
            <option value="us">United States</option>
            <option value="uk">United Kingdom</option>
            <option value="ca">Canada</option>
        </select>
    </div>
    
    <button type="submit">Submit</button>
</form>`,
          explanation: "HTML forms are essential for collecting user input, with various input types and validation attributes."
        }
      ],
      description: "Learn the building blocks of web development"
    },
    {
      title: "Multimedia & Links",
      topics: [
        {
          name: "Images & Media",
          example: `<!-- Responsive Image -->
<img src="image.jpg" 
     alt="Description" 
     loading="lazy"
     width="800"
     height="600">

<!-- Video Player -->
<video controls width="100%">
    <source src="video.mp4" type="video/mp4">
    <source src="video.webm" type="video/webm">
    Your browser doesn't support video.
</video>

<!-- Audio Player -->
<audio controls>
    <source src="audio.mp3" type="audio/mpeg">
    <source src="audio.ogg" type="audio/ogg">
    Your browser doesn't support audio.
</audio>`,
          explanation: "HTML5 provides robust support for multimedia elements, including images, video, and audio, with fallback options and lazy loading."
        },
        {
          name: "Advanced Links",
          example: `<!-- External Link -->
<a href="https://example.com" 
   target="_blank" 
   rel="noopener noreferrer">
    Visit Example Site
</a>

<!-- Email Link -->
<a href="mailto:contact@example.com?subject=Hello">
    Send Email
</a>

<!-- Phone Link -->
<a href="tel:+1234567890">
    Call Us
</a>

<!-- Download Link -->
<a href="document.pdf" download>
    Download PDF
</a>`,
          explanation: "HTML links can do more than just navigate between pages, including opening email clients, initiating phone calls, and downloading files."
        }
      ],
      description: "Master embedding media and creating connections"
    },
    {
      title: "Advanced HTML5",
      topics: [
        {
          name: "Canvas",
          example: `<canvas id="myCanvas" width="400" height="400"></canvas>

<script>
const canvas = document.getElementById('myCanvas');
const ctx = canvas.getContext('2d');

// Draw a neon rectangle
ctx.strokeStyle = '#ff00ff';
ctx.shadowColor = '#ff00ff';
ctx.shadowBlur = 20;
ctx.strokeRect(50, 50, 300, 300);

// Add gradient text
const gradient = ctx.createLinearGradient(0, 0, 400, 0);
gradient.addColorStop(0, '#ff00ff');
gradient.addColorStop(1, '#00ffff');
ctx.fillStyle = gradient;
ctx.font = '48px Arial';
ctx.fillText('HTML5 Canvas', 60, 200);
</script>`,
          explanation: "The HTML5 Canvas API provides a powerful way to draw graphics, animations, and interactive content programmatically."
        },
        {
          name: "Web Storage",
          example: `<!-- Local Storage Example -->
<script>
// Store data
localStorage.setItem('theme', 'dark');
localStorage.setItem('user', JSON.stringify({
    name: 'John',
    lastLogin: new Date()
}));

// Retrieve data
const theme = localStorage.getItem('theme');
const user = JSON.parse(localStorage.getItem('user'));

// Session Storage
sessionStorage.setItem('tempData', 'This is temporary');
</script>`,
          explanation: "HTML5 Web Storage (localStorage and sessionStorage) provides ways to store data locally in the browser, with different persistence levels."
        }
      ],
      description: "Explore modern HTML5 features and APIs"
    }
  ];

  return (
    <div className="space-y-12">
      <header className="text-center mb-12">
        <h1 className={`text-6xl font-bold mb-4 ${darkMode ? 'text-blue-400' : 'text-blue-600'}
          ${darkMode ? 'shadow-[0_0_30px_rgba(59,130,246,0.5)]' : ''}`}>
          HTML Zero to Hero
        </h1>
        <p className={`text-xl ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
          Build the foundation of web development with our comprehensive HTML guide
        </p>
      </header>

      <div className="grid md:grid-cols-3 gap-8">
        {sections.map((section, index) => (
          <div
            key={index}
            className={`p-6 rounded-lg border-2 ${
              darkMode
                ? 'bg-gray-800 border-blue-500 shadow-[0_0_25px_rgba(59,130,246,0.4)]'
                : 'bg-white border-blue-300 shadow-lg'
            } hover:transform hover:scale-105 transition-all duration-300`}
          >
            <h2 className={`text-2xl font-bold mb-4 ${darkMode ? 'text-blue-400' : 'text-blue-600'}`}>
              {section.title}
            </h2>
            <p className={`mb-4 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              {section.description}
            </p>
            <div className="space-y-4">
              {section.topics.map((topic, topicIndex) => (
                <div key={topicIndex} className="space-y-2">
                  <button
                    onClick={() => setExpandedSection(expandedSection === index * 100 + topicIndex ? null : index * 100 + topicIndex)}
                    className={`w-full flex items-center justify-between p-2 rounded-md transition-colors ${
                      darkMode
                        ? 'bg-gray-700 hover:bg-gray-600'
                        : 'bg-gray-100 hover:bg-gray-200'
                    }`}
                  >
                    <span className={`flex items-center ${darkMode ? 'text-blue-400' : 'text-blue-600'}`}>
                      <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                      {topic.name}
                    </span>
                    {expandedSection === index * 100 + topicIndex ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                  </button>
                  
                  {expandedSection === index * 100 + topicIndex && (
                    <div className={`p-4 rounded-md ${darkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                      <p className="mb-4">{topic.explanation}</p>
                      <pre className={`p-4 rounded-md overflow-x-auto ${
                        darkMode ? 'bg-gray-900 text-blue-400' : 'bg-gray-800 text-blue-300'
                      }`}>
                        <code>{topic.example}</code>
                      </pre>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HtmlSection;