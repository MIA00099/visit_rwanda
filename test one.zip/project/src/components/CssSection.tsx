import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const CssSection = ({ darkMode }: { darkMode: boolean }) => {
  const [expandedSection, setExpandedSection] = useState<number | null>(null);

  const sections = [
    {
      title: "Basics of CSS",
      topics: [
        {
          name: "Selectors",
          example: `/* Element Selector */
div { color: blue; }

/* Class Selector */
.highlight { background: yellow; }

/* ID Selector */
#header { font-size: 2em; }

/* Attribute Selector */
input[type="text"] { border: 1px solid; }`,
          explanation: "CSS selectors define which elements to style. They range from simple element selectors to complex combinators and pseudo-classes."
        },
        {
          name: "Colors",
          example: `/* Different ways to define colors */
.color-hex { color: #ff5733; }
.color-rgb { color: rgb(255, 87, 51); }
.color-hsl { color: hsl(12, 100%, 60%); }
.color-alpha { background: rgba(255, 87, 51, 0.5); }`,
          explanation: "CSS provides multiple ways to define colors, including hexadecimal, RGB, HSL, and their alpha variants for transparency."
        },
        {
          name: "Typography",
          example: `/* Typography properties */
.text-styling {
  font-family: 'Arial', sans-serif;
  font-size: 1.2rem;
  font-weight: bold;
  line-height: 1.5;
  letter-spacing: 0.05em;
}`,
          explanation: "Typography in CSS controls how text is displayed, including font families, sizes, weights, and spacing."
        }
      ],
      description: "Master the fundamental concepts of CSS styling"
    },
    {
      title: "Layout & Positioning",
      topics: [
        {
          name: "Flexbox",
          example: `/* Flexbox Container */
.flex-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 1rem;
}

/* Flex Items */
.flex-item {
  flex: 1;
  order: 2;
}`,
          explanation: "Flexbox is a one-dimensional layout method for arranging items in rows or columns, with powerful alignment and spacing capabilities."
        },
        {
          name: "Grid",
          example: `/* Grid Container */
.grid-container {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-gap: 20px;
}

/* Grid Item */
.grid-item {
  grid-column: span 2;
  grid-row: 1 / 3;
}`,
          explanation: "CSS Grid is a two-dimensional layout system that can handle both columns and rows simultaneously."
        }
      ],
      description: "Learn how to create responsive and dynamic layouts"
    },
    {
      title: "Advanced Styling",
      topics: [
        {
          name: "Animations",
          example: `/* Define the animation */
@keyframes neon-pulse {
  0% { box-shadow: 0 0 10px #ff00ff; }
  50% { box-shadow: 0 0 20px #ff00ff; }
  100% { box-shadow: 0 0 10px #ff00ff; }
}

/* Apply the animation */
.neon-element {
  animation: neon-pulse 2s infinite;
}`,
          explanation: "CSS animations allow you to create smooth transitions between styles using keyframes and animation properties."
        },
        {
          name: "Transforms",
          example: `/* 3D Transforms */
.transform-3d {
  transform: perspective(1000px)
             rotateX(45deg)
             rotateY(45deg);
  transform-style: preserve-3d;
}`,
          explanation: "CSS transforms enable you to modify elements in 2D or 3D space, including rotation, scaling, and perspective effects."
        }
      ],
      description: "Explore advanced CSS techniques for modern web design"
    }
  ];

  return (
    <div className="space-y-12">
      <header className="text-center mb-12">
        <h1 className={`text-6xl font-bold mb-4 ${darkMode ? 'text-pink-400' : 'text-pink-600'} 
          ${darkMode ? 'shadow-[0_0_30px_rgba(236,72,153,0.5)]' : ''}`}>
          CSS Zero to Hero
        </h1>
        <p className={`text-xl ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
          Master the art of styling with our comprehensive CSS guide
        </p>
      </header>

      <div className="grid md:grid-cols-3 gap-8">
        {sections.map((section, index) => (
          <div
            key={index}
            className={`p-6 rounded-lg border-2 ${
              darkMode
                ? 'bg-gray-800 border-pink-500 shadow-[0_0_25px_rgba(236,72,153,0.4)]'
                : 'bg-white border-pink-300 shadow-lg'
            } hover:transform hover:scale-105 transition-all duration-300`}
          >
            <h2 className={`text-2xl font-bold mb-4 ${darkMode ? 'text-pink-400' : 'text-pink-600'}`}>
              {section.title}
            </h2>
            <p className={`mb-4 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              {section.description}
            </p>
            <div className="space-y-4">
              {section.topics.map((topic, topicIndex) => (
                <div key={topicIndex} className="space-y-2">
                  <button
                    onClick={() => setExpandedSection(expandedSection === index * 100 + topicIndex ? null : index * 100 + topicIndex)}
                    className={`w-full flex items-center justify-between p-2 rounded-md transition-colors ${
                      darkMode
                        ? 'bg-gray-700 hover:bg-gray-600'
                        : 'bg-gray-100 hover:bg-gray-200'
                    }`}
                  >
                    <span className={`flex items-center ${darkMode ? 'text-pink-400' : 'text-pink-600'}`}>
                      <span className="w-2 h-2 bg-pink-500 rounded-full mr-2"></span>
                      {topic.name}
                    </span>
                    {expandedSection === index * 100 + topicIndex ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                  </button>
                  
                  {expandedSection === index * 100 + topicIndex && (
                    <div className={`p-4 rounded-md ${darkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                      <p className="mb-4">{topic.explanation}</p>
                      <pre className={`p-4 rounded-md overflow-x-auto ${
                        darkMode ? 'bg-gray-900 text-pink-400' : 'bg-gray-800 text-pink-300'
                      }`}>
                        <code>{topic.example}</code>
                      </pre>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CssSection;